package com.example.testgamesource;

import android.graphics.Canvas;

import com.example.testgamesource.graphics.Sprite;
import com.example.testgamesource.object.Player;
import com.example.testgamesource.object.PlayerState;

public class Animator {
    private static final int MAX_UPDATES_BEFORE_NEXT_MOVE_FRAME = 5;
    private Sprite[] playerSpriteArray;
    private int updatesBeforeNextMoveFrame;

    public Animator(Sprite[] playerSprite) {
        this.playerSpriteArray = playerSprite;
    }

    public void draw(Canvas canvas, GameDisplay gameDisplay, Player player) {
        switch (player.getPlayerState().getState()){
            case NOT_MOVIES:
              drawFrame(canvas, gameDisplay, player, playerSpriteArray[0]);
                 break;
            case STARTED_MOVING:
                updatesBeforeNextMoveFrame = MAX_UPDATES_BEFORE_NEXT_MOVE_FRAME;
                drawFrame(canvas, gameDisplay, player, playerSpriteArray[1]);
                break;
            case IS_MOVING_LEFT:
                updatesBeforeNextMoveFrame--;

                break;
            case IS_MOVING_RIGHT:

                break;
            case FINISH_MOVING:

                break;
            default:
                break;
        }
    }
    public void drawFrame(Canvas canvas, GameDisplay gameDisplay, Player player, Sprite sprite){
        sprite.draw(canvas,
                (int)gameDisplay.gameToDisplayCoordinatesX(player.getPositionX()) - sprite.getWidth() / 2,
                (int)gameDisplay.gameToDisplayCoordinatesY(player.getPositionY()) - sprite.getHeight() / 2
        );
    }
}
