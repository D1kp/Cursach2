package com.example.testgamesource;

import com.example.testgamesource.object.GameObject;

public class GameDisplay {

    private double gameToDisplayCoordinateOffsetX;
    private double gameToDisplayCoordinateOffsetY;
    private double displayCenterX;
    private double displayCenterY;
    private GameObject centerObject;
    private double gameCenterX;
    private double gameCenterY;

    public GameDisplay(GameObject centerObject, int widthPixel, int heightPixel){
        this.centerObject = centerObject;

        displayCenterX = widthPixel/2.0;
        displayCenterY = heightPixel/2.0;
    }

    public void update(){
        gameCenterX = centerObject.getPositionX();
        gameCenterY = centerObject.getPositionY();

        gameToDisplayCoordinateOffsetX = displayCenterX - gameCenterX;
        gameToDisplayCoordinateOffsetY = displayCenterY - gameCenterY;
    }

    public double gameToDisplayCoordinatesX(double x) {
        return x + gameToDisplayCoordinateOffsetX;
    }
    public double gameToDisplayCoordinatesY(double y) {
        return y + gameToDisplayCoordinateOffsetY;
    }
}
