package com.example.testgamesource.graphics;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.example.testgamesource.R;

public class SpriteSheet {
    private Bitmap bitmap;
    public SpriteSheet(Context context){
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inScaled = false;
        bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.testwallk, bitmapOptions);
    }

    public Sprite[] getPlayerSprite(){
        Sprite[] spriteArr = new Sprite[3];
        spriteArr[0] = new Sprite(this, new Rect(0*70, 0, 1*70, 70));
        spriteArr[1] = new Sprite(this, new Rect(1*70, 0, 2*70, 70));
        spriteArr[2] = new Sprite(this, new Rect(2*70, 0, 3*70, 70));
        /*spriteArr[3] = new Sprite(this, new Rect(3*70, 0, 4*70, 70));
        spriteArr[4] = new Sprite(this, new Rect(4*70, 0, 5*70, 70));
        spriteArr[5] = new Sprite(this, new Rect(5*70, 0, 6*70, 70));*/

        return spriteArr;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }
}
