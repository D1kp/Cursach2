package com.example.testgamesource;


import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import com.example.testgamesource.gamepanel.GameOver;
import com.example.testgamesource.gamepanel.Joystick;
import com.example.testgamesource.gamepanel.Perfomance;
import com.example.testgamesource.graphics.SpriteSheet;
import com.example.testgamesource.object.Circle;
import com.example.testgamesource.object.Enemy;
import com.example.testgamesource.object.Player;
import com.example.testgamesource.object.Spell;

import java.util.ArrayList;
import java.util.Iterator;

public class Game extends SurfaceView implements SurfaceHolder.Callback {
    private final Player player;
    private final Joystick joystick;
    //private Enemy enemy;
    private GameLoop gameLoop;
    private ArrayList<Enemy> enemyList;
    private ArrayList<Spell> spellList;
    private static final int N = 2;
    private int joystickPointerId = 0 ;
    private int numberOfSpellToCast = 0;
    private GameOver gameOver;
    private Perfomance perfomance;
    private GameDisplay gameDisplay;


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (joystick.getIsPressed()){
                    numberOfSpellToCast++;
                }else if(joystick.isPressed((double)event.getX(), (double)event.getY())){
                    joystickPointerId = event.getPointerId(event.getActionIndex());
                    joystick.setIsPressed(true);

                } else {
                    numberOfSpellToCast++;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if(joystick.getIsPressed()){
                    joystick.setActuator((double)event.getX(), (double)event.getY());
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if(joystickPointerId == event.getPointerId(event.getActionIndex())) {
                    joystick.setIsPressed(false);
                    joystick.resetActuator();
                }
                return true;
        }

        return super.onTouchEvent(event);
    }

    public Game(Context context) {
        super(context);

        SurfaceHolder surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);

        gameLoop = new GameLoop(this, surfaceHolder);

        gameOver = new GameOver(context);
        joystick = new Joystick(275, 350, 70, 60);
        perfomance = new Perfomance(context, gameLoop);

        SpriteSheet spriteSheet = new SpriteSheet(context);
        Animator animator = new Animator(spriteSheet.getPlayerSprite());

        player = new Player(context, joystick, 500, 200, 30, animator);
        enemyList = new ArrayList<Enemy>();
        spellList = new ArrayList<Spell>();

        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) getContext()).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        gameDisplay = new GameDisplay(player, displayMetrics.widthPixels, displayMetrics.heightPixels);


        setFocusable(true);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if(gameLoop.getState().equals(Thread.State.TERMINATED)){
            gameLoop = new GameLoop(this, holder);
        }
        gameLoop.startLoop();

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        perfomance.drawUPS(canvas);
        perfomance.drawFPS(canvas);
        player.draw(canvas, gameDisplay);
        joystick.draw(canvas);
        for(Enemy enemy: enemyList){
            enemy.draw(canvas, gameDisplay);
        }
        for(Spell spell: spellList){
            spell.draw(canvas, gameDisplay);
        }

        if(player.getHealthPoints() <= 0){
            gameOver.draw(canvas);
        }

    }



    public void update() {

        if(player.getHealthPoints() <= 0){
            return;
        }

        joystick.update();
        player.update();
        if(Enemy.readyToSpawn()){
            enemyList.add(new Enemy(getContext(), player));
        }

        while (numberOfSpellToCast > 0){
            spellList.add(new Spell(getContext(), player));
            numberOfSpellToCast--;
        }

        for(Enemy enemy: enemyList){
            enemy.update();
        }

        for(Spell spell: spellList){
            spell.update();
        }

        Iterator<Enemy> iteratorEnemy = enemyList.iterator();

        while(iteratorEnemy.hasNext()){
            Circle enemy = iteratorEnemy.next();
            if(Circle.isColliding(enemy, player)){
                iteratorEnemy.remove();
                player.setHealthPoints(player.getHealthPoints() - 1);
                continue;
            }
            Iterator<Spell> iteratorSpell = spellList.iterator();
            while (iteratorSpell.hasNext()){
                Circle spell = iteratorSpell.next();
                if(Circle.isColliding(spell, enemy)){
                    iteratorSpell.remove();
                    iteratorEnemy.remove();
                    break;
                }
            }

        }
        gameDisplay.update();
    }

    public void pause() {
        gameLoop.stopLoop();
    }
}
