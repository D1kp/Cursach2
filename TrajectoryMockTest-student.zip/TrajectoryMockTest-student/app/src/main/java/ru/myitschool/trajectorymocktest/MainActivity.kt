package ru.myitschool.trajectorymocktest

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import ru.myitschool.trajectorymocktest.databinding.ActivityMainBinding

const val BASE_URL = "https://gitee.com/api/v5/users/"

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service: UserController = retrofit.create(UserController::class.java)


        binding.buttonSend.setOnClickListener {
            Thread() {
                run {
                    val call: Call<User> = service.get(binding.editTextLogin.text.toString())
                    val userResponse: Response<User> = call.execute()
                    val result: User? = userResponse.body()
                    this.runOnUiThread{binding.requestedData.text = "public_repos: ${result?.public_repos}"}
                    Log.i("Retrofit", "$result")
                }
            }.start()
        }
    }
}

data class User (
    val login: String,
    val id: Int,
    val public_repos: Int
    )


interface UserController{
    @POST("/hello")
    fun hello(@Body user: User): Call<Boolean>

    @GET("/list")
    fun list(): Call<List<User>>

    @GET("{login}")
    fun get(@Path("login") name:String): Call<User>
}
